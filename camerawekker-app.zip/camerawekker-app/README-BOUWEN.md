# Camera-Wekker als echte Android-app

Dit project verpakt je bestaande web-app in een echte Android-app (via Capacitor).
Je gegevens blijven bewaard, en de app is te installeren zoals elke andere app.

Je hoeft **geen** Android Studio te installeren. GitHub bouwt de APK gratis voor je.

## Stap 1 — Zet dit project in een GitHub-repo
1. Maak een nieuwe (private mag) repo aan, bijvoorbeeld `camera-wekker-app`.
2. Upload **alle** bestanden uit deze map, met behoud van de mappenstructuur
   (dus ook de map `.github/` en `www/`).
   - Via de website: "Add file" > "Upload files" en sleep de hele inhoud erin.
     Let op dat de map `.github/workflows/build-android.yml` mee komt.

## Stap 2 — Laat GitHub de APK bouwen
1. Ga in je repo naar het tabblad **Actions**.
2. Kies links **"Bouw Android APK"** en klik rechts **"Run workflow"**.
3. Wacht tot de build groen is (eerste keer ~5 tot 10 minuten).
4. Open de voltooide run en download onderaan bij **Artifacts** het bestand
   **camera-wekker-apk** (dat is een zip met `app-debug.apk` erin).

## Stap 3 — Installeer op je telefoon
1. Pak de zip uit en zet `app-debug.apk` op je Samsung.
2. Tik het bestand aan om te installeren. De eerste keer vraagt Android om
   "installeren van onbekende bronnen" toe te staan voor je bestandsbeheerder of browser.
3. Open de app en geef toestemming voor de camera en meldingen.

## Wat werkt er in deze eerste versie
- De app is echt geinstalleerd (eigen icoon, eigen app), niet meer een browsertab.
- Alles wat je in de app instelt (alarmen, loterij, geluiden) blijft bewaard.
- De camera-herkenning werkt zoals in de web-app.

## Wat nog NIET in deze eerste versie zit
- Op de achtergrond afgaan (met de app dicht) komt in de **volgende stap**.
  Nu gaat het alarm nog alleen af als de app openstaat, net als de web-versie.
  Ik doe dat bewust in twee stappen: eerst zeker weten dat installeren en de
  camera goed werken op jouw toestel, daarna het achtergrond-alarm aanzetten.

## Eerlijk over testen
Ik kan een Android-build hier niet zelf uitvoeren of testen. Het kan dus zijn dat
de eerste build een kleine aanpassing nodig heeft (meestal iets met de camera in de
app-schil of een versie-detail). Omdat GitHub elke keer automatisch opnieuw bouwt,
is aanpassen zo gebeurd: stuur me de foutmelding uit de Actions-log en ik fix het.

## Alternatief zonder GitHub: online build-dienst
Wil je liever niet via GitHub, dan kun je dit hele project als zip uploaden bij een
online build-dienst zoals VoltBuilder (volt.build). Die levert een ondertekende APK
terug, ook zonder Android Studio. Zo'n dienst is wel betaald (proefperiode gratis).
Voor jou is de gratis GitHub-route het handigst.

## Handig om te weten
- App-naam: Camera-Wekker. App-id: nl.konings.camerawekker.
- De build maakt een "debug"-APK. Dat is prima om zelf te installeren.
  Voor een publieke Play Store-versie is later een ondertekende "release"-APK nodig.
